--# © Lima Resources, Inc. 
--# discord.gg/n8ER692uUj
--# Se está vendo isso é por que gostou do meu trabalho ;)



fx_version 'adamant'
game 'gta5'

shared_script '@vrp/lib/utils.lua'

server_scripts {
  'server/*'
}

client_scripts {
  'client/*'
}

files {
  'build/**/*',
  'config.json',
}